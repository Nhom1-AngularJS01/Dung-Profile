(() => {
    angular.module("BlogApp", ['ui.router', 'ui.bootstrap']);
})();